# OwnerFs native bind：架构判断与首轮实测

日期：2026-10-01。沿用 [RFC 0001](../docs/rfcs/0001-ownerfs-native-bind-mount.md)、[验证计划](native-bind-validation-plan.md)与既有 E1～E16，不重启方案。Issue [#42](https://github.com/lelezi257/dms/issues/42)。本文件是当前候选的实验结论，不是发布验收或已实现能力声明。

## 明确结论

1. **同路径 bind、同一 backing、已接受的文件对象/close-to-open 边界可行。** E11～E13 在真实 Linux VM、当前 Node/Meta/TLS/P2P 链路给出证据；E16 另证明 native Home 与 ordinary remote 的两个重开案例。完整挂载过渡、生产 READY 与生命周期集成仍有缺失，不能从这些局部证据推导全部通过。
2. **当前标准 FUSE/P2P + native 混合写入不能满足完整追加/偏移合同。** E15 的一次远端 2MiB write 被 native 写入分隔，顺序追加也返回错误 SEEK_CUR。FUSE 按分块请求处理、WRITE 回复仅返回字节数；Home inode 的追加位置/锁与远端 FUSE inode 不同。没有整次 syscall 边界与结束偏移，仅在 Home 加用户态逐请求锁不能完整修复。此结论针对当前边界，不是对所有 bind/定制客户端方案的不可行性证明。POSIX owner 的简单代理也被 E4 否定，完整替代路线未证明。旧 cwd/dirfd 的已接受边界不豁免这些要求。
3. **仅覆盖 workspace，当前零 TTL 策略没有达到完整绝对路径的 native 性能。** 以下实际数据关闭“是否只要 bind 成功就达到 native”的问题。进入 native cwd 后的数据路径接近 ext4；原路径绝对访问仍有稳定、大幅的祖先查询开销。不能要求使用者改名或只使用相对路径来宣告原目标实现。

因此，当前候选的完整架构与性能验收均未通过。bind 基础机制有价值，但还需要解决路径解析及混合访问仲裁；通用重试、排空工程不能代替这些架构决策。

## P1 本地元数据/小文件数据

在 A VM 运行同一 `gcc -O2` syscall 工作负载，10,000 个 4KiB 文件，按 create/write/close、stat、read/close、readdir、rename、unlink 分项计时。每个路径/并发组合先预热一次，再交替运行五组成对 ext4/native；MooseFS 同条件串行插入。计时不含 SSH、控制文件轮询、初始 mkdir/chdir 与结果序列化。读取逐文件校验完整内容，stat 校验长度，readdir 校验条目数；失败即中止该样本。

下表任务耗时为六个分项的合计中位数。**比值是逐轮成对比值的中位数，不是两列中位数相除。**

| 访问方式 | 并发 | ext4（ms） | native bind（ms） | native/ext4 成对比值 | MooseFS（ms） |
| --- | ---: | ---: | ---: | ---: | ---: |
| 绝对路径 | 1 | 332.75 | 6496.20 | **19.276** | 35924.32 |
| 绝对路径 | 8 | 353.55 | 1328.50 | **4.161** | 21255.03 |
| native cwd 相对路径 | 1 | 328.48 | 328.12 | **0.992** | 37461.68 |
| native cwd 相对路径 | 8 | 332.90 | 328.38 | **1.036** | 21705.58 |

绝对路径并发1的五个比值为 20.923、19.276、17.763、20.261、18.607；并发8为 3.523、4.176、4.161、4.267、3.430。相对路径并发1为 0.981、1.040、1.002、0.992、0.985；并发8为 1.036、1.062、0.937、1.255、0.986。前两组是稳定退化；后两组只支持“接近原生”，没有证明每个分项均满足既定 `median(T_native/T_ext4) ≤ 1.0`，不自行加入5%/10%宽限。

完整分项、每轮 wall/client CPU、操作 p50/p95/p99、配对来源与无效配置标记在 [机器可读数据](acceptance/results/native-bind-p1-20261001.json)。尾延迟是每轮实际操作分布，不把五个任务耗时当作可靠 p99；未提供跨轮合并的 p99。Root/epoch/Home/namespace、Node SHA、卷及资源前后记录保留在原始归档。

### 可比性与限制

- A：Ubuntu24.04、kernel6.8.0-142、2vCPU、约5925MiB RAM、无 swap；同一个 `/dev/sdb1` ext4 数据卷。ext4 与 native 两条路径访问同一 Home source inode，测试目录各自新建并清空；MooseFS 唯一 chunkserver 也在 A 同一卷，master 在 ctl。C 仅编译基线。没有同时运行其他 benchmark。
- DMS 使用新构建 `release [optimized]` 的 Linux lib-test Node driver 和优化版 Meta，沿用真实生产 bootstrap/TLS/P2P；生产 native admission 仍未接入。MooseFS 固定 commit `ac106b2ec8661ff00def725d042cb67d3ca2184d`，实际版本4.59.2-1/build2106，默认客户端缓存、nice0；专用 `native-bind-one` 类定义为单份 `*`，只有 A 注册 chunkserver。
- 这是新文件创建后依次 stat/read 的 warm 可见性工作负载，不是冷读、持久化写或普通 FUSE-only 产品基线。native 与 ext4 都是普通 close；MooseFS 使用 stock close/flush，`HDD_FSYNC_BEFORE_CLOSE=0`、`CHANGELOG_SAVE_MODE=0`。**B001 物理数据/CRC/元数据持久性对等性仍未资格化**，这些数据不证明 durable-write 比值门槛。
- 绝对路径的实际前缀长度/层数不同，报告源码与路径；后续优化后的严格微小差距需控制此因素。它不能解释更短 native 前缀反而出现的 4～19 倍退化。相对操作路径相同，初始导航成本另计。Hyper-V/Windows 宿主缓存未完全控制；本轮不宣称 cold。
- 第一个完整计时 run 的长时间采样超过语义 Actor 的五分钟寿命，收尾失败。72个计时任务已完成，原始 runner 仍为 FAIL；独立校验核对归档/实际回复/计时/二进制/退出，确认 Node/Meta 正常退出及正常 detach，仅资格化计时诊断。不能改写失败为全实验 PASS。
- 原完整 run 的绝对路径/并发1早期 MooseFS 仍为默认2CP；轮1、2不用于单副本比较。另一个短 run 在正确单副本配置下完成预热加两组成对补充，正常退出，补足这组五个 MooseFS 配对。数据明确记录跨 run 身份及被排除样本，不覆盖或静默替换历史记录。

## 原始输入与复核

- 完整计时：`network-probe-20261001T120749-90422701`，72样本，原 runner FAIL/Actor lifetime；独立计时核验通过，非阶段通过。
- 有限补充：`network-probe-20261001T122407-211d5bd3`，9样本，原 runner PASS/正常 teardown；只补绝对路径并发1，不替代全矩阵。
- release 构建记录：`/home/lzc/workspace/dms/evidence/ownerfs-native-bind/20261001/native-performance-build-20261001T115511/`，Node/Meta 构建均 terminal0。Node 原 SHA `89ae34954a8fadcb0217decf02d3be2ad3d9d508df27fc4924678691a9eec316`、执行 SHA `409363724228d3a1de051158d6ec9e627452c55af0b95d9f4607feb5c3eb5c72`；只移除 DWARF。Meta 执行 SHA `77b9435f23c198de3e53d3552979ce2beca1ad79f05e8fafdc19bdfab6796cfe`。
- benchmark SHA `a5a7c66a2c38e521d23d0f857b4bd732dd0e3a33f74c7b136c1fa879bcaf7ff3`；源 [ownerfs_native_benchmark.c](acceptance/probes/ownerfs_native_benchmark.c)，C VM严格编译及真实 ext4 行为自检通过。
- verifier SHA `c7e63f53b1a63dea3fbb5313d21c41ffc6ad8cd1f8548dd185a8eab42a07cc7e`。两个 run 的原始证据通过，坏归档SHA、伪造读回复、伪造计时均被拒绝。E13/E14/E15/E16重新离线复核保留各自原结论，包括E15语义FAIL。
- Windows 原始副本 `C:/workspace/code/dms/local/native-bind-vm/<run>/`；A/B VM `/mnt/afsdata/ownerfs-native-network/<run>/`，ctl `/mnt/afsstate/ownerfs-native-network/<run>/`。原始归档 SHA 与结果 SHA 收录机器数据；MFS stock 包 SHA `0999130ea116a024452755e9bd04cc803533c6a27c3d0079649d160645b7c9e7`。

## 核心容器 Agent 场景：C0/C1 与容器 P1

用户补充的核心流程是：管理面在 OwnerFs 根创建 workspace，确认 native 挂载后，只把该 workspace 挂入容器交给 Agent。此场景已经在 A 的真实 runc OCI 容器运行，独立于上面的宿主路径结果；没有要求 Agent 改目录名或仅使用相对路径。

`network-probe-20261001T125205-fc4c5860` 的流程与证据：

1. 沿用优化版 Node/Meta/TLS/P2P。FUSE mkdir → manager native activate，原 export 的 source 为 ext4 `device=2065,inode=1049463`。容器运行时先进入已核验的 Node mount namespace，再按**原 export 路径**进行 bind；native lane 未直接改用隐藏 backing 路径。
2. 容器内 workspace 是 `/ownerfs/agent1`，父目录是最小只读 rootfs 自身的 `/ownerfs`。native 与 ext4 对照最终都绑定同一个 source inode；容器的 mount/PID/network/IPC/UTS/cgroup namespace 与 Node 不同。native 容器内的实际 workspace mount 为 ext4、`statfs=0xef53`，其 mountinfo 无 FUSE mount。
3. 三个实际容器内 `/ownerfs` 仅列出 `agent1`；创建父级条目返回 EROFS。宿主上已存在的兄弟 workspace/外部 marker，通过 `..`、宿主绝对路径、backing 父路径、symlink 和 host PID/proc-root 均返回 ENOENT/EACCES/ENOTDIR。自身原文件内容读取正确，创建/写入的 marker 在实际 source 上核对成功。
4. Agent 实验进程为 UID/GID0，但全部 capabilities 为空、NoNewPrivs=1；只读 rootfs、独立 PID/proc 与 namespace，未挂宿主 root/proc 或整个 OwnerFs 根。这里证明的是上述配置的宿主**目录数据隔离**；Linux mountinfo 仍可显示 mount-root 路径字符串，没有承诺隐藏挂载元数据、证明任意恶意代码无逃逸，或已经支持任意 UID/user-namespace 映射。
5. benchmark 在容器内运行，runtime 启动/exec/SSH 均不计入 syscall 阶段时间。三方使用相同 rootfs/runtime/目标路径深度与长度/权限/数据/轮次；ext4/native 是同一个物理 source，不同等长后缀的新实验子目录。容器祖先本身为 native，因此绝对访问无需经过宿主 OwnerFs 根的 FUSE 查询。

容器同一 P1 工作负载（一次预热、五轮正式交替配对，三方共72任务）的结果如下。完整任务仍为六个分项合计；**比值取逐轮配对中位数**，与两列中位数相除不同。

| 容器内访问方式 | 并发 | ext4（ms） | native（ms） | native/ext4 成对比值 | MooseFS（ms） |
| --- | ---: | ---: | ---: | ---: | ---: |
| 绝对路径 | 1 | 333.08 | 330.03 | **1.050** | 36059.09 |
| 绝对路径 | 8 | 337.18 | 343.54 | **1.019** | 20866.04 |
| 相对路径 | 1 | 360.17 | 339.22 | **1.003** | 36287.03 |
| 相对路径 | 8 | 343.00 | 339.04 | **0.995** | 21560.62 |

这关闭“容器里是否仍有宿主 FUSE 祖先的数量级退化”的问题：本轮没有4～19倍差距，路径机制符合原生访问预期。但24个分项/路径/并发组合中16个配对中位比值大于1，且逐轮比例跨过1；不能把这轮波动数据判成全部严格 native 门槛通过，也不自行加入5%容差。它是近原生的实际证据，性能验收仍开放。MooseFS 单副本 stock 可见性对照延续 E17，B001强持久性仍未资格化。

原 runner PASS，三个容器都受控停止/delete 后才 detach，Meta/Node/短期 bootstrap Actors 全部正常退出；独立复核72个实际 runtime 回复、source、spec、capabilities、namespace、mountinfo、输入/逐文件/归档 SHA 和完整采样矩阵。伪造 timing/source/隔离结果、坏归档、伪造远端读取均被拒绝。

- 完整表格/全样本：[container P1 数据](acceptance/results/native-bind-container-p1-20261001.json)，SHA `193107e6b3ae4586d1e5915d92f8fef85673fb95a707b9e2da117fbdb4772de8`。
- runc `1.3.4-0ubuntu1~24.04.1`（OCI spec1.2.1），执行 SHA `bdce4d45b2dd217491db8a98c8484b161e225ce49c15ebc1ba42077fb7c07d50`。这是实际 OCI runtime 实验，未宣告 Docker/Podman daemon 已完成集成。[OCI root/mount 规范](https://github.com/opencontainers/runtime-spec/blob/main/config.md)、[runc 文档](https://github.com/opencontainers/runc/blob/main/README.md)。
- probe 执行 SHA `dcacaa08aff4edf5cdbd2c6e04ba3a3d2872a17c11209f58dc959328c3e8ff94`；冻结输入 `native-network-native-candidate-20261001T125157`，源码见 [容器驱动](acceptance/probes/ownerfs_native_container.py)和 [进程探针](acceptance/probes/ownerfs_native_container_probe.c)。
- 原始 A/B/ctl 归档分别为 `e39f2f77b90ac0b2b0049c22ede0b1d64666ce73246223c158cbe03e5017a566`、`437c62148f28459db18860bfd57899260d6719bd927ae5b225511bcbfe039d67`、`aee67cd89ea1f8b57d7ae1657986aea3522a02f038f5f4990a98be4ff1b58449`。完整身份/spec/原始回复已保留，未打包宿主数据或大工作集来替代验证。
- 首次 `network-probe-20261001T124743-f5c49050` 为观察器 FAIL、零计时样本：detached init 继承采集 pipe，造成 runtime 已退出但 communicate 等待；PID1 默认 TERM 又不能终止 sleep，改为专用带 TERM handler 的 init；归档跟随 `/dev/core` symlink 读取 `/proc/kcore`，改为只校验常规文件且不跟随 symlink。失败输入/人工核验的 PID/start/boot/exe SHA、收尾与恢复归档均保留，恢复 A 归档 SHA `aa3c90ff621d65b386fa16fd934ca23cea34677e99ea96e452873c4802a1ddce`。原 FAIL 不改写为 PASS。

容器 P2/P3 及跨 namespace 回收检查正作为下一组独立实验执行；当前本节不代表这些项目通过。生产管理面须把原 export 发布给实际 runtime 所在 namespace，核验最终 Agent 对象，再 READY/启动；宿主 daemon 仅拿到路径字符串并不满足这一条件。原 export 正常 umount 与所有容器引用排空的等价性尚需独立证据，不能沿用同 namespace busy 结论代替。

## 下一步限于 bind 的关键问题

1. 关闭绝对路径祖先开销：检查仅合成不可变根属性的安全缓存，以及挂载根名称/epoch 的失效机制；或评估最终 Agent namespace 中保留同名路径但使用 native 祖先。两者都需要实证，后者还需核对 Agent 的根目录创建/枚举合同；当前未选择、未实现。不能直接给整个 workspace 正 TTL 或假设用户只走 cwd。
2. 对追加/偏移、POSIX owner 给出维持完整合同的仲裁/客户端路线，或取得明确合同修改。未获得豁免前持续保留架构未通过；不把它们当作另一位 AI 的通用可靠性兜底已解决。
3. 补顺序、随机与远端时间数据，以及适用屏障/缓存条件的可比性。P1 已给出决定性负面数据，但不冒充 P2～P4；整个性能阶段仍开放。
4. 通用 drain/retry/recovery 继续由另一位 AI 负责。当前分支保留此前 bind 基础及共享接口边界；交付仍为 issue → 隔离分支 → 不合入 PR，review 必须看到以上未决项。
